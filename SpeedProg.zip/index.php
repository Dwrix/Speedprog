<?php 
header("Location: pages/index/index.php");
?>